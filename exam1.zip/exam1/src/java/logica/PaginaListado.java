
package logica;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import modelos.Solicitud;
import modelos.ListaClientes;

@ManagedBean
@SessionScoped
public class PaginaListado  implements Serializable {
    
    @ManagedProperty(value="#{detallesBean}")
    DetallesBean detalles;

    public DetallesBean getDetalles() {
        return detalles;
    }

    public void setDetalles(DetallesBean detalles) {
        this.detalles = detalles;
    }
    ListaClientes laLista;
    
    public PaginaListado() {
        laLista=new ListaClientes();
        laLista.agregar("1/10/17","Arianna","Dante","Solicitud"
                + " acerca de soluciones tecnicas de computo a domicilio activacion y demas controles a realizar.");
        laLista.agregar("3/5/17","Jaomr","Alhra","Solicitud "
                + "de reparacion sistemas de computo de la empresa AMSDA de todas sus maquinas para laborar.");
        laLista.agregar("6/8/17","Keyla","Vega","Solicitud "
                + "de instalacion de sistemas de software de la empresa GAP.");
        laLista.agregar("16/2/17","Bryan","Salmeron","Solicitud "
                + "de instalacion de sistemas de software a domicilio.");
    }

    public ListaClientes getLaLista() {
        return laLista;
    }

    public void setLaLista(ListaClientes laLista) {
        this.laLista = laLista;
    }
    /* metodos que son llamados desde la pagina */
    public String cargarNuevo(){
        return "nuevo";
    }
    public String detalles(String fec) {
        for (Solicitud  e : laLista.getLista()) {
            if(e.getFecha().equals(fec)){
                detalles.clientes=e;
                return "detalles";
            }
        }
        return "index";
    }
    
}
