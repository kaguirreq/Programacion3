
package logica;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;


@ManagedBean
@RequestScoped

public class Crear {
    @ManagedProperty(value="#{paginaListado}")
    PaginaListado paginaListado;

    public PaginaListado getPaginaListado() {
        return paginaListado;
    }

    public void setPaginaListado(PaginaListado paginaListado) {
        this.paginaListado = paginaListado;
    }
    
    String fecha;
    String nombre;
    String apellido;
    
    public Crear() {
    }
    
    public String Guardar(){
        /* guardamos */
        paginaListado.laLista.agregar(fecha,nombre,apellido,"");
        /* regresamos al index */
        return "index";
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

   
}
