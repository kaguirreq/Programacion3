
package logica;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import modelos.Solicitud;



@ManagedBean
@SessionScoped

public class DetallesBean {

    Solicitud clientes;

    public Solicitud getClientes() {
        return clientes;
    }

    public void setClientes(Solicitud clientes) {
        this.clientes = clientes;
    }

   
    public DetallesBean() {
    }
    
    public  String regresar(){
        return "index";
    }
}
