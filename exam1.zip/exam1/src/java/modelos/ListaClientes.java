
package modelos;

import java.util.ArrayList;

public class ListaClientes  {
    
    ArrayList<Solicitud> lista;
    public ListaClientes () {
        lista=new ArrayList<>();
    }
    
    public ArrayList<Solicitud> getLista() {
        return lista;
    }

    public void agregar(String fec, String nom, 
        String ape, String deta) {
        
        Solicitud e=new Solicitud();
        
        e.setApellido(ape);
        e.setFecha(fec);
        e.setNombre(nom);
        e.setDetalle(deta);
        lista.add(e);
    }
}
